import de.hsrm.mi.prog.util.StaticScanner;

public class Labyrinth {
	public static void main(String[] args) {
		int ausgew�hlt = labyrinthNummer();
		char[][] labyrinth = labyrinthAuswahl(ausgew�hlt);
		
		for (char[] zeile : labyrinth) {
			for (char spalte : zeile) {
				System.out.print(spalte + " ");
			}
			System.out.println();
		}
		
	}

	public static int labyrinthNummer() {
		int auswahl = StaticScanner.nextInt();
		//System.out.println("test");
		return auswahl;
	}
	
	/*public static void labyrinthAusgeben(char[][] labyrinthAusgabe) {
		int spielerAuswahl = welchesLabyrinth();
		for (char[] zeile : labyrinthAuswahl(spielerAuswahl)) {
			for (char spalte : zeile) {
				System.out.print(spalte + " ");
			}
			System.out.println();
		}
		
	}
*/
	public static char[][] labyrinthAuswahl(int gewaehlt) {
		char[][] labyrinth = null;

		char[][] labyrinth1 = { 
				{ ' ', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.' },
				{ ' ', '.', ' ', ' ', ' ', '.', ' ', ' ', ' ', ' ', ' ', '.' },
				{ ' ', '.', '.', ' ', '.', '.', ' ', '.', ' ', '.', ' ', '.' },
				{ ' ', '.', ' ', ' ', '.', ' ', ' ', '.', ' ', '.', ' ', '.' },
				{ ' ', '.', ' ', ' ', ' ', ' ', ' ', '.', ' ', '.', ' ', 'A' },
				{ ' ', '.', ' ', '.', ' ', '.', ' ', '.', ' ', ' ', ' ', '.' },
				{ ' ', '.', ' ', '.', ' ', '.', '.', '.', ' ', '.', ' ', '.' },
				{ ' ', '.', ' ', '.', ' ', ' ', ' ', '.', ' ', '.', ' ', '.' },
				{ ' ', 'B', ' ', '.', '.', '.', ' ', '.', ' ', ' ', ' ', '.' },
				{ ' ', '.', '.', '.', ' ', '.', '.', '.', '.', '.', '.', '.' }, };

		char[][] labyrinth2 = {

		};

		char[][] labyrinth3 = {

		};
		switch (gewaehlt) {
		case 1:
			labyrinth = labyrinth1;
			break;
		case 2:
			labyrinth = labyrinth2;
			break;
		case 3:
			labyrinth = labyrinth3;
			break;
		}

		return labyrinth;
	}
	
	public static void rechteHandRegel() {
		char[] blickRichtung = {'^','>','<','v'};
		
		
		
	}
}
